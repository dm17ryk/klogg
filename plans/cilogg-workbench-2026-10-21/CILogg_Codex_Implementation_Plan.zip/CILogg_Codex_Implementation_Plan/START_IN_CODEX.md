# Start This Implementation in Codex App

Open your local CILogg repository in Codex App. Extract the plan package into `docs/superpowers/plans/2026-10-21-cilogg-workbench/`, preserving any newer repository changes. Paste the following task into Codex App.

```text
Implement the CILogg Developer Workbench plan in this repository.

Read the current AGENTS.md and the plan package at
docs/superpowers/plans/2026-10-21-cilogg-workbench/.
Start with README.md, MASTER_GUIDE.md, 00-product-spec.md,
BASELINE.md, TASK_INDEX.json, FEATURE_COVERAGE.md, PROGRESS.json,
PROJECT_HEALTH_AUDIT.md, GITHUB_MILESTONES.md and MILESTONES.json.

Begin with G01: inspect the real current HEAD, working tree, toolchain,
existing P00–P05 status, action/scenario/plugin systems and code-impact tools.
Reconcile newer completed work instead of reimplementing it. Do not reset or
overwrite unrelated work, stop the user's active captures, or assume the
research SHA is the required execution base.

Start H01-H10 project-readiness work with its explicit lightweight dependencies.
The public README patch, release/channel fixes, roadmap/milestone payloads,
package publication, community routes and social preview are part of this plan.
Do not treat prepared milestone payloads or generated artwork as published GitHub
objects/settings. Preserve actual returned IDs and publication evidence.

Continue through G02/G03 before feature tasks, then use the next runnable task in the dependency
graph. Implement one independently reviewable task/slice at a time with the
required tests, GUI discovery, shared CLI/Python/MCP operations, documentation,
diagnostics, migration and rollback. Read each task's consuming contracts and
current source before editing. Preserve C++17/Qt5/Qt6 and the bounded shared
analysis/action/plugin foundations. Keep early V02 native charts independent
from the later structured/time/query stack.

Use this Codex App environment's normal execution workflow; delegate only when
authorized by the current user/repository/skill instructions and when tasks
have frozen independent interfaces. Integrate shared registration files serially.
Use the available model appropriate to task complexity without assuming model
IDs or automatic model-switch APIs exist.

After each slice, run focused and relevant complete checks, inspect the diff
and code-impact results, and update PROGRESS.json with actual evidence,
limitations, changed contracts, commit/PR and the next runnable task. Treat
unknown/blocked/skipped checks separately from passing checks. Continue useful
independent work when a task is blocked; do not drop its requirements.

The full scope includes general developer log exploration, all listed chart
families and linked dashboards, patterns/comparisons/correlation, workflows,
assertions/replay/CI, Docklight-style communication testing, integrations,
packs, accessibility and cross-platform release quality. FEATURE_COVERAGE.md
is the scope checklist. Do not reduce the product to CP/C8000-specific behavior.

Work through reviewable increments. Keep external publishing/merging and
destructive operations subject to the user's actual execution instruction.
Report completed evidence and remaining tasks truthfully; a plan checkbox
does not establish implementation or hardware support.
```

**Spec:** `00-product-spec.md` and `MASTER_GUIDE.md`; source evidence below supplements that specification.

## Resume prompt

```text
Continue the CILogg Developer Workbench implementation from PROGRESS.json.
Inspect the current repository first. Select the next task whose hard
dependencies are complete, read its subsystem plan and required contracts,
and continue from the last verified evidence. Preserve unfinished unrelated
work and active captures. Update progress and the next runnable task when done.
```

## Task review prompt

```text
Review task TASK_ID against its specification, current diff and evidence.
Check source identity, exact values/time/units, limits/cancellation, legacy
compatibility, GUI/CLI/Python/MCP parity, failure paths, tests and rollback.
Verify neighboring instances of any discovered defect. Distinguish actual
failures, unsupported capabilities and missing evidence. Do not claim unrun
platform or hardware checks passed.
```
