# Project Readiness, Distribution and Community Implementation Plan

**Goal:** Make the public project accurate, navigable, installable and welcoming before expanding the feature roadmap. This subsystem supplements all existing data, visualization, automation and Docklight work.

**Evidence:** Audited source at master `ed2d70baa067b1d9198618ba1430094487bf26f6` on 2026-10-21. Current release data and inherited-resource comparison are in [PROJECT_HEALTH_AUDIT.md](PROJECT_HEALTH_AUDIT.md).

**Spec:** `00-product-spec.md` and `MASTER_GUIDE.md`. H tasks do not require G02/G03's product test harness unless their implementation actually changes runtime behavior. Documentation changes use link/render/schema checks.

## Review Focus

Distinguish unavailable metadata from missing resources, zero issue counts from documentation completeness, current CI flags from historical release metadata, upstream packages from this fork, and generated artwork from configured repository settings. Package-manager/server provisioning remains explicit publication work with its actual acceptance evidence.


## H01 — Repair the public README and repository identity

**Integrated hard dependencies:** G01. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** A newcomer can identify this fork, download CILogg and reach its own support and roadmap.

**Files and ownership:** `README.md`; `CONTRIBUTING.md`; `CHANGELOG.md`; `repository About metadata`.

**Contract:** README links advertise only verified resources for dm17ryk/klogg; upstream history remains clearly attributed.

**Implementation steps:**
- [ ] Apply the narrow prepared README-publication.patch after checking current HEAD; preserve the existing CLI and automation documentation.
- [ ] Remove the inherited Codacy project badge, fixed milestone numbers, missing v26.04 comparison, unverified package claims, obsolete release-tag tables and upstream community badges.
- [ ] Keep one downloads section, current CI workflow link, GitHub Issues/Discussions links and a plain milestones link. Add a progress badge only after H04 returns a real milestone number.
- [ ] Correct the overview: CILogg derives from klogg, which derives from glogg; distinguish current capabilities from future workbench features. Preserve contributor attribution.
- [ ] Set About description/topics for developer log exploration and automation; replace the upstream homepage with an existing CILogg-owned destination, such as this repository documentation, after verifying ownership.

**Acceptance and verification:**
- Render the README on GitHub; exercise download/help/roadmap navigation and all relative document/image links.
- Scan for the three obsolete continuous platform tags, milestone/4, milestone/8, v26.04 and unsupported package-install assertions; inspect each remaining match.
- Confirm a zero documentation issue count is described as issue metadata, not proof that documentation is complete.

**Rollback:** Revert only the documentation/metadata change; do not delete upstream historical references or releases.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H02 — Make release channels and artifact provenance trustworthy

**Integrated hard dependencies:** G01, H01. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** Users can reliably distinguish stable releases from testing builds and identify the exact source in each binary.

**Files and ownership:** `.github/workflows/ci-release.yml`; `.github/workflows/ci-build.yml`; `scripts/generate_update_manifest.py`; `scripts/validate_release_windows.ps1`; `scripts/validate_release_linux.sh`; `scripts/validate_release_macos.sh`; `latest.json`; `docs/releases.md (new)`.

**Contract:** Release identity = channel, version, immutable source SHA, CI run ID and per-asset SHA256; one validated run supplies every publish job.

**Implementation steps:**
- [ ] Reuse the existing ci/stable input, --prerelease/--latest flags, platform validators, update manifest and checksum generation. These mechanisms already exist in the audited workflow.
- [ ] Resolve one CI run and source SHA before any validation job; pass the same run ID to all downloads. Fail mismatched version, source SHA, architecture or required asset sets.
- [ ] Audit historical continuous releases marked prerelease=false. Prepare explicit metadata corrections and verify update-client/channel behavior before publishing them; do not assume current flags caused the historical state.
- [ ] Replace delete-and-recreate publication with an immutable release policy: if the tag/version already exists, compare expected identity and fail on differences. Never silently move a released tag.
- [ ] Generate a single stable/testing download index from verified release metadata. Do not advertise a nonexistent stable channel. Keep historical release links and update-client compatibility.
- [ ] Inspect archive contents rather than trusting size or filename. In particular verify the small PDB ZIP assets before claiming symbols are available; mark unavailable optional artifacts explicitly.

**Acceptance and verification:**
- Use fixture releases for stable, preview, missing stable, old misclassified preview, partial platform assets and mixed source runs.
- Existing platform validators and update-manifest tests pass; install/start/upgrade checks record each tested OS/architecture.
- A second publish attempt cannot delete a release or replace assets; the published manifest resolves to the tested commit, not a mutable master label.

**Rollback:** Keep existing releases/tags intact; revert index generation or channel metadata with the recorded previous values. Do not roll back by replacing released bytes.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H03 — Replace decorative quality badges with verifiable checks

**Integrated hard dependencies:** G01. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** CI indicators describe real checks on this fork, with enough evidence for contributors to assess failures.

**Files and ownership:** `.github/workflows/ci-build.yml`; `.github/workflows/codeql-analysis.yml`; `.clang-tidy`; `scripts/codex/run-tests.ps1`; `README.md`; `docs/quality.md (new)`.

**Contract:** Each badge names its check, repository, branch and evidence destination; passing build status is never called an overall quality grade.

**Implementation steps:**
- [ ] Inventory current test, static analysis and build jobs; preserve working checks and inspect whether fork-specific code scanning is configured before adding a badge.
- [ ] Expose a small set of reliable build/test/static-analysis indicators. Keep Codacy removed unless a CILogg-owned project is actually provisioned and reports this repository.
- [ ] Document supported platforms, focused versus complete checks, local commands and retained failure artifacts. Introduce clang-tidy checks incrementally with a recorded baseline rather than hiding unrelated findings.
- [ ] Publish coverage only if instrumented execution generates a valid report for the advertised commit. Do not invent a quality score or equate missing external metadata with bad C++ code.

**Acceptance and verification:**
- An intentional fixture failure makes its named CI gate fail and preserves useful output.
- Every displayed badge opens the corresponding real workflow/report for this fork.
- Documentation distinguishes build success, test success, static analysis and checks that have not run.

**Rollback:** Remove a misleading badge independently of CI behavior; retain prior reports and recorded baselines.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H04 — Publish the implementation roadmap as GitHub milestones

**Integrated hard dependencies:** G01. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** The complete plan is discoverable in GitHub, with phased ownership and measurable progress.

**Files and ownership:** `ROADMAP.md (new)`; `docs/superpowers/plans/2026-10-21-cilogg-workbench/`; `README.md`; `.github/ISSUE_TEMPLATE/feature.yml (new)`; `GitHub milestones and issue metadata`.

**Contract:** Each plan task has one primary milestone; GitHub numbers and URLs are stored only from real creation responses. Task dependencies remain authoritative.

**Implementation steps:**
- [ ] Use GITHUB_MILESTONES.md and MILESTONES.json from this package. Check all existing open and closed milestones for duplicates before creating anything.
- [ ] Create or reuse the nine proposed milestones and put their objectives, exit criteria and exact task IDs in descriptions. M00-style keys are plan identifiers, not assumed GitHub milestone numbers.
- [ ] Put the versioned plan into repository documentation and link it from ROADMAP.md. Never use a sandbox URL as a public GitHub plan link.
- [ ] Initially create one tracking issue per milestone with explicit task checklists, or create task issues when their execution starts. Explain that milestone percentages count closed issues and PRs, not checklist items.
- [ ] Create status/area labels only when used: status: ready for testing, status: need documentation, area: visualization, area: protocol, area: automation, area: packaging. Keep documentation unfinished until its acceptance evidence exists.
- [ ] Assign related implementation PRs to their actual milestone. Preserve completed P00–P05 work as baseline credit; do not create new unfinished duplicates for it. Leave due dates unset until estimates and capacity exist.

**Acceptance and verification:**
- Every task is assigned exactly once; every requirement retains an owner; the task DAG remains acyclic.
- Milestone links and any progress badges resolve to actual numbers after publication.
- Read-back verifies titles, descriptions, state and URLs; an unavailable API is recorded as blocked publication, never as proof that no milestones exist.

**Rollback:** Preserve discussion history; close or rename duplicate empty milestones only after review. Keep the local mapping and published identity ledger.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H05 — Document current features and the path from first use

**Integrated hard dependencies:** H01, H04. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** Developers understand what works today, what is planned and how to complete common tasks.

**Files and ownership:** `DOCUMENTATION.md`; `MCP.md`; `BUILD.md`; `CONTRIBUTING.md`; `docs/features.md (new)`; `docs/quickstart.md (new)`; `ROADMAP.md (new)`; `website/static/screenshots/`.

**Contract:** Feature status is current, experimental, planned or platform-dependent, with a source/release evidence link for shipped behavior.

**Implementation steps:**
- [ ] Create a concise feature-status matrix linking current Regex Lab, Value Counts, sources, actions, scenarios and supported automation entry points to their documentation.
- [ ] Add short quickstarts for opening/searching a file, live capture, Regex Lab/Value Counts and an existing automation recipe. Add chart/dashboard instructions only as those features land.
- [ ] Refresh screenshots from the actual app and identify the build/version shown. Provide developer-domain examples beyond embedded hardware.
- [ ] Reconcile BUILD/AGENTS/README toolchain statements and actual test options. Keep proposed workbench API names in the plan until implementation exposes them.
- [ ] Require a user-visible behavior change to update its documentation and sample together; use need-documentation issues for concrete missing material.

**Acceptance and verification:**
- Follow each documented current quickstart on its stated build; record missing platform evidence explicitly.
- Feature matrix and release notes agree with binary provenance and current command discovery.
- All local links and sample paths exist; copied examples use the supported CLI/Python/MCP contracts.

**Rollback:** Restore previous documentation pages while retaining corrected links and feature-status evidence.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H06 — Publish maintained Windows package manifests

**Integrated hard dependencies:** H02, H05. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** Windows package-manager commands install this CILogg fork and can upgrade or uninstall it reliably.

**Files and ownership:** `packaging/windows/`; `packaging/manifests/windows/ (new)`; `.github/workflows/package-manifests.yml (new)`; `docs/releases.md`.

**Contract:** Package identity, publisher, architecture, immutable installer URL, checksum and silent installer behavior are independently verified for CILogg.

**Implementation steps:**
- [ ] Inspect the current installer technology, installed product identity, command names and updater behavior before choosing package IDs. Never claim dm17ryk/klogg is a Winget PackageIdentifier.
- [ ] Start with a maintained project-owned Scoop bucket if useful, then prepare Winget and Chocolatey submissions following their official manifest and validation requirements.
- [ ] Test x64 and ARM64 only where real installers are published. Separate stable and preview identities/channels so default package upgrades do not unexpectedly install testing builds.
- [ ] Generate candidate manifests from verified stable release metadata, retain pinned URLs/checksums and review updates before registry submission.
- [ ] Add README installation commands only after the public catalog entry is accepted and a clean install resolves to dm17ryk CILogg. Existing klogg manifests are upstream packages, not evidence of CILogg publication.

**Acceptance and verification:**
- Clean installation, launch, CLI discovery, upgrade and uninstall succeed on each claimed architecture.
- Manifest validation passes; remote bytes match SHA256 and installed version/product identity.
- A preview release or incomplete release cannot update the stable manifest.

**Rollback:** Pin the last verified manifest; preserve released installers. Follow each catalog rollback process rather than rewriting a published version.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H07 — Publish maintained macOS and Linux distribution routes

**Integrated hard dependencies:** H02, H05. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** macOS and Linux users receive accurate install instructions and maintained package routes.

**Files and ownership:** `packaging/macos/`; `packaging/linux/`; `packaging/manifests/macos/ (new)`; `.github/workflows/package-manifests.yml (new)`; `docs/releases.md`.

**Contract:** Advertise only routes that distribute this fork; architecture, OS baseline, update behavior and package ownership are explicit.

**Implementation steps:**
- [ ] Use verified GitHub DMG/AppImage/DEB/RPM assets immediately. Test installation/startup and identify platform prerequisites from the actual package.
- [ ] Prepare a project-owned Homebrew tap/cask with real Intel and Apple Silicon URLs, checksums, bundle identity and uninstall behavior; pursue the main catalog only when its current acceptance rules are met.
- [ ] Provide accurate Linux AppImage and supported DEB/RPM instructions. Decide separately whether maintaining signed APT/DNF repositories is justified; a release asset is not automatically a distribution repository.
- [ ] Submit distro/community recipes through their normal review process. Restore Repology package status only after independently published CILogg recipes are indexed; changing a badge name does not register a package.
- [ ] Automate version/checksum candidate updates from stable provenance and test upgrade paths. Verify macOS signing/notarization and Linux compatibility before making corresponding claims.

**Acceptance and verification:**
- Package installation and upgrade launch the intended CILogg version and architecture.
- Homebrew/source recipe points to this fork; upstream klogg remains a distinct package.
- README claims match accepted public catalog entries and actual verified download routes.

**Rollback:** Retain direct release downloads and last verified recipes; withdraw unsupported install instructions without deleting historical assets.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H08 — Establish CILogg-owned community and support routes

**Integrated hard dependencies:** H01. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** Users can ask questions, report reproducible bugs and propose features without being sent to upstream communities.

**Files and ownership:** `CONTRIBUTING.md`; `.github/ISSUE_TEMPLATE/bug.yml (new)`; `.github/ISSUE_TEMPLATE/feature.yml (new)`; `.github/ISSUE_TEMPLATE/config.yml (new)`; `docs/community.md (new)`; `README.md`; `GitHub Discussions settings`.

**Contract:** GitHub issues and versioned documentation remain the durable source for bugs, decisions and releases; optional chat points to a verified CILogg-owned community.

**Implementation steps:**
- [ ] Use the already-enabled Discussions area for questions, ideas/showcase and announcements. Route reproducible defects to issue forms asking for OS, build, source type, steps and a shareable minimal log.
- [ ] Remove inherited Discord/Gitter badges from the primary support path. Keep upstream acknowledgements separate from CILogg support.
- [ ] Create a separate CILogg Discord only when its owner can maintain it and a real invite exists. Suggested initial channels: announcements, help, feature-ideas, showcase and development.
- [ ] For a new Discord, configure moderation roles, a clear welcome/support policy and minimal notifications; mirror final decisions and defects into GitHub rather than losing them in chat.
- [ ] Add invite/server-count badges only after checking ownership and the public invite. Do not invent a server ID or assume the existing upstream invite belongs to this fork.

**Acceptance and verification:**
- A new user can reach help, feature planning and bug reporting from the README.
- Issue forms produce actionable environment/version information; support links use verified destinations.
- The core community setup is complete using Discussions even if the optional Discord remains unprovisioned and clearly recorded.

**Rollback:** Keep GitHub Issues/Discussions working; remove an invalid invite without disrupting existing issue history.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H09 — Keep project links and publication metadata healthy

**Integrated hard dependencies:** H01, H02, H04, H05. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** Future renames and releases cannot silently reintroduce broken badges, download links or package claims.

**Files and ownership:** `scripts/check_project_metadata.py (new)`; `scripts/project-links.json (new)`; `.github/workflows/project-health.yml (new)`; `tests/project_metadata/ (new)`.

**Contract:** Classify checks as valid, invalid or unavailable. Provider throttling and authorization failures are not missing-resource evidence.

**Implementation steps:**
- [ ] Validate relative documentation links, referenced image files, workflow filenames and configured release channels on pull requests.
- [ ] Keep external checks in a bounded, retry-aware manual/scheduled CI job with cached results: release tags, current milestone number, package manifests and verified support invite.
- [ ] Inspect catalog manifest origins and identities instead of accepting any HTTP 200 page as proof of a CILogg package.
- [ ] Treat HTTP 404/410 as missing only for a reachable endpoint; record 401/403/429, provider errors and tool capability restrictions as unavailable. Do not make docs-only PRs fail because an external badge provider is temporarily down.
- [ ] Produce a concise artifact identifying the broken destination and owning configuration. Add a project-health badge only once this workflow exists and runs.

**Acceptance and verification:**
- Fixture checks distinguish missing tags, valid zero issue counts, rate limits, generic HTML fallback pages, wrong-fork package manifests and duplicated download blocks.
- A changed workflow filename or absent relative file is caught before merge.
- No external-network fixture is required for deterministic pull-request validation.

**Rollback:** Disable the external job independently; keep deterministic local metadata checks and their last useful reports.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## H10 — Add a CILogg social preview and reusable project artwork

**Integrated hard dependencies:** H01. Capability-conditional dependencies described below are additional runtime gates; they do not reverse these edges.


**Outcome:** Shared repository links display a clear CILogg image consistent with the universal developer-tool direction.

**Files and ownership:** `Resources/branding/cilogg-social-preview.jpg (new)`; `Resources/branding/social-preview.md (new)`; `GitHub repository Settings > Social preview`.

**Contract:** An opaque 2:1 image, at least 1280×640, PNG/JPG/GIF under 1 MB, with the exact CILogg name and no unimplemented feature claims.

**Implementation steps:**
- [ ] Reuse the artwork generated with this plan update. Preserve its original; create an upload-ready file under GitHub’s size limit without changing the composition or product name.
- [ ] Keep the wording CILogg and Logs • Visualizations • Automation. The abstract traces are decorative artwork, not a fabricated screenshot or performance measurement.
- [ ] Record the image-generation prompt and the selected asset identity in the branding note so future changes are intentional.
- [ ] Upload the selected image in repository Settings > Social preview with an authorized repository owner session. Committing the file or adding it to README does not set GitHub’s social-preview metadata.
- [ ] Verify the repository settings preview and a newly shared repository URL. Record cache delays separately from an unsuccessful settings update.

**Acceptance and verification:**
- Inspect dimensions, format and bytes; verify name, descriptor, repository address and thumbnail legibility.
- The configured repository preview shows the selected file and no screenshot-like claims about unfinished features.
- Distinguish asset prepared from preview configured in progress evidence.

**Rollback:** Restore the previous social preview through Settings; keep both source assets for review.

**References:** [repository README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md), [release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml), [GitHub milestones](https://docs.github.com/en/rest/issues/milestones), [social preview guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).
