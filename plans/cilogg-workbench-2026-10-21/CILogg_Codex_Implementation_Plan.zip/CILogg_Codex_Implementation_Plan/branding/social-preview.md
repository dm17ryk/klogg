# CILogg Social Preview

The selected artwork is [cilogg-social-preview.jpg](cilogg-social-preview.jpg). It was generated with the built-in image generation tool, then exported to JPEG for GitHub's upload limit. The original generated PNG is preserved separately. The artwork is decorative branding, not an application screenshot or performance chart.

## Publication

The image was uploaded to repository Settings > General > Social preview on 2026-10-22. The configured image was visually verified in GitHub Settings. Social-network cache propagation was not checked. A committed image or README banner alone does not configure this setting.

GitHub recommends a 2:1 image at least 1280×640 for best display and requires PNG/JPG/GIF under 1 MB. The prepared JPEG retains the generated 1774×887 composition. See the [official instructions](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview).

## Generation prompt

```text
Use case: ads-marketing.
Asset type: GitHub repository social preview for the open-source CILogg developer application.
Create one finished, polished, wide 2:1 social preview banner, exactly 1280 by 640 pixels, with an opaque dark background. This is brand artwork, not a screenshot or a diagram.
The exact product name is "CILogg" (C I L capital, o g g lowercase). Render it very large in clean confident contemporary sans-serif lettering, crisp white, strongly readable at thumbnail scale. Below it, render only this smaller exact descriptor: "Logs • Visualizations • Automation". At bottom left include the understated exact repository address "github.com/dm17ryk/klogg".
Visual concept: streams of fine monospaced log-like marks gradually resolve into elegant cyan and mint traces, a few amber event markers, a compact histogram silhouette and subtle connected analytical lines on the right. They are abstract decorative motifs with no axes, numerical data, fake metrics, or invented application UI. On the left, quiet negative space makes the title dominant. Deep charcoal/navy background with restrained cool glows; editorial, sophisticated, useful engineering software aesthetic. Keep all text and essential artwork at least 64 pixels inside every edge, balanced generous margins. No people, robots, mascots, hardware, glossy 3D objects, browser frames, performance claims, badges, or extra text. Clean and welcoming to all developers, not an embedded-only product. Professional export-ready raster artwork.
```

