# CILogg Public Project Audit

Checked 2026-10-21 against [master ed2d70b](https://github.com/dm17ryk/klogg/commit/ed2d70baa067b1d9198618ba1430094487bf26f6), release metadata, the upstream README and selected official package manifests. This audit evaluates project presentation and publication. It is not a source-code quality assessment.

**Spec:** `00-product-spec.md` and `MASTER_GUIDE.md`; source evidence below supplements that specification.


## Published GitHub roadmap — 2026-10-22

The nine milestones and nine tracking issues below are live. The CILogg social preview is configured and visually verified in repository Settings. The product implementation tasks remain planned; publishing roadmap objects does not complete them.

| Plan key | GitHub milestone | Tracking issue |
|---|---|---|
| M00 | [#1 — M00 · Project readiness and distribution](https://github.com/dm17ryk/klogg/milestone/1) | [#48](https://github.com/dm17ryk/klogg/issues/48) |
| M01 | [#2 — M01 · First linked charts and everyday usability](https://github.com/dm17ryk/klogg/milestone/2) | [#49](https://github.com/dm17ryk/klogg/issues/49) |
| M02 | [#3 — M02 · Structured logs and source workflows](https://github.com/dm17ryk/klogg/milestone/3) | [#50](https://github.com/dm17ryk/klogg/issues/50) |
| M03 | [#4 — M03 · Analytical dashboards and linked visualizations](https://github.com/dm17ryk/klogg/milestone/4) | [#51](https://github.com/dm17ryk/klogg/issues/51) |
| M04 | [#5 — M04 · Investigations, automation and CI](https://github.com/dm17ryk/klogg/milestone/5) | [#52](https://github.com/dm17ryk/klogg/issues/52) |
| M05 | [#6 — M05 · Advanced visualizations and data](https://github.com/dm17ryk/klogg/milestone/6) | [#53](https://github.com/dm17ryk/klogg/issues/53) |
| M06 | [#7 — M06 · Protocol Lab and Docklight capabilities](https://github.com/dm17ryk/klogg/milestone/7) | [#54](https://github.com/dm17ryk/klogg/issues/54) |
| M07 | [#8 — M07 · Developer integrations and reusable packs](https://github.com/dm17ryk/klogg/milestone/8) | [#55](https://github.com/dm17ryk/klogg/issues/55) |
| M08 | [#9 — M08 · Cross-platform release acceptance](https://github.com/dm17ryk/klogg/milestone/9) | [#56](https://github.com/dm17ryk/klogg/issues/56) |

README cleanup, package catalog submissions and remaining implementation work are tracked in M00 and the other milestones. They were not performed by creating these roadmap objects.


## Findings and ownership

| Item | Verified finding | Implementation owner |
|---|---|---|
| Codacy badge | CILogg README and variar/klogg README use the identical project ID `f6db6ef0be3a4a5abff94111a5291c45`. Changing the link owner does not create a new analysis project. | H01 removes inherited badge; H03 establishes real check evidence. |
| Commits badge | The referenced `v26.04` Git ref returned 404 from GitHub. | H01 removes the missing-tag comparison; H09 validates configured refs. |
| Latest testing links | All three release-tag endpoints `continuous-win`, `continuous-linux`, `continuous-osx` returned 404. They are repeated twice in README. | H01 supplies one verified releases link; H02 supplies reliable channel discovery. |
| Actual downloads | Release `continuous-26.04.2.1035`, published 2026-10-21 at 18:46:15Z, has Windows x64/ARM64 installer and portable archives, Linux x86_64/aarch64 assets and macOS Intel/Apple Silicon assets, plus update/checksum files. Presence is verified; installation was not tested. | H02 provenance/validation; H06/H07 publication. |
| Stable label | The inspected latest continuous release is marked `prerelease=false`, so a generic stable-release badge can promote a testing build. Current workflow already selects `--prerelease` for ci and `--latest` for stable; reconcile historical publication rather than assuming those flags are absent. | H02. |
| Source versus released binary | Value Counts merged as PR #45 at 19:35:51Z, after the latest inspected release. Master containing P05 does not establish that the 18:46 release includes it. | G01 credits merged source; H02 records exact binary source SHA. |
| Milestone badges | README hardcodes milestone 4 and links milestone 8, matching inherited upstream structure. The screenshot shows a failed milestone badge. Milestone listing was not accessible through the connected tool, so this audit does not claim the repository has no milestones. | H04 checks existing milestones and records real IDs; H01 removes hardcoded inherited IDs. |
| Documentation badges | A zero count reports matching issues, if the query is valid. It does not prove there are no missing docs or that the named label exists. | H04/H05 concrete docs tracking; H09 distinguishes zero from error. |
| Scoop | Official `ScoopInstaller/Extras/bucket/cilogg.json` returned 404. This does not establish that no private or community CILogg bucket exists. | H06. |
| Homebrew | Official `Homebrew/homebrew-cask/Casks/c/cilogg.rb` returned 404. The public `klogg` cask identifies variar/klogg and is an upstream package. | H07. |
| Other package assertions | Chocolatey, Winget, distro repositories and Repology claims were not verified as installable packages for this fork. The supplied screenshot reports no known CILogg packages. Avoid advertising them until exact manifests/catalog entries are accepted and tested. | H06/H07. |
| Community | README Discord server ID and invite match variar/klogg upstream; Gitter also names the upstream community. CILogg repository metadata already has Discussions enabled. | H08 uses own GitHub support; separate Discord remains optional. |
| Repository homepage | About metadata points to `klogg.filimonov.dev`, an upstream destination. | H01 uses an existing verified CILogg-owned destination. |
| Social preview | New CILogg artwork has been generated. An image file or README image alone does not configure GitHub Social preview. | H10 validates the upload-ready artifact and records the Settings change separately. |

## Immediate documentation correction

`proposals/README-publication.patch` is prepared against the audited README. It preserves detailed CLI/automation content and removes unsupported publication claims. It is not applied to GitHub. Recheck the current file before applying the patch; do not overwrite newer edits.

## Milestone publication status

Nine milestone descriptions and a complete task assignment are supplied in `GITHUB_MILESTONES.md` and `MILESTONES.json`. GitHub milestone numbers and tracking issue URLs are now recorded in MILESTONES.json; due dates remain unset. The current GitHub toolset can create issues but does not expose milestone creation; browser fallback requires approval under the browser-tool instructions. No GitHub objects were changed during the original source audit. A subsequent authorized publication on 2026-10-22 created nine milestones and nine tracking issues and configured the social preview; the publication record below supersedes the earlier prepared-only state.

## Primary references

- [Audited CILogg README](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/README.md)
- [Audited release workflow](https://github.com/dm17ryk/klogg/blob/ed2d70baa067b1d9198618ba1430094487bf26f6/.github/workflows/ci-release.yml)
- [Inspected continuous release](https://github.com/dm17ryk/klogg/releases/tag/continuous-26.04.2.1035)
- [Upstream README](https://github.com/variar/klogg/blob/master/README.md)
- [Official Homebrew klogg listing](https://formulae.brew.sh/cask/klogg)
- [GitHub milestone API](https://docs.github.com/en/rest/issues/milestones)
- [GitHub social preview requirements and configuration](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/customizing-your-repositorys-social-media-preview)
- [Winget manifest reference](https://learn.microsoft.com/en-us/windows/package-manager/package/manifest)
- [Chocolatey package creation](https://docs.chocolatey.org/en-us/create/)
- [Scoop manifests](https://github.com/ScoopInstaller/Scoop/wiki/App-Manifests)
- [Homebrew cask cookbook](https://docs.brew.sh/Cask-Cookbook)

